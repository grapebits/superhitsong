<div style="background-color : aliceblue; padding-left:3%;padding-right:3%;border:1px solid red;">
</b><p style="color:black; font-family:courier-new;font-weight:normal;">
Hello!<br /><br />
You have now had your website on internet with help of GrapeBits. I hope you will love it.
<br /><br />If you have any Problem regarding the software or have any suggestion, feel free to contact me at <i><a href="mailto:harsh.mi@live.com">harsh.mi@live.com</a></i>
<br /><br />
Best regards,<br />
<a href="http://instagram.com/harsh_comp">Harsh Mishra</a>, creator of <a href="http://github.com/grapebits">GrapeBits</a>
</p>
</div>