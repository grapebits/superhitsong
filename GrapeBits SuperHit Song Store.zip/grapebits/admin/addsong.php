<?php 
 include "header.php";
 include "addsongprocess.php";
 include "addsongbody.php";
 include "footer.php"
 
?>