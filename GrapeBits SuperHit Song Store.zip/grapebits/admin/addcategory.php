<?php 
 include "header.php";
 include "addcategoryprocess.php";
 include "addcategorybody.php";
 include "footer.php"
 
?>