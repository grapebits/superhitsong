<?php 
 include "header.php";
 include "editheadbody.php";
 include "footer.php"
 
?>