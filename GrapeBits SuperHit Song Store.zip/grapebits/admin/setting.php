<?php 
 include "header.php";
 include "settingbody.php";
 include "footer.php"
 
?>