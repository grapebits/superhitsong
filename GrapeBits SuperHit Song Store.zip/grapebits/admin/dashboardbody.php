
<div id="editor">
<div id="title"><h1>Dashboard</h1><p class="simple_text">Welcome <?php echo $username; ?></p><br />
<?php include "dashboard2.php"; ?>
<br />
</div>
</div>
</div>
</div>