<?php 
 include "header.php";
 include "changepasswordbody.php";
 include "footer.php"
 
?>