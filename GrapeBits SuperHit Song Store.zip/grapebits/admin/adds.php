<?php 
 include "header.php";
 include "addsbody.php";
 include "footer.php"
 
?>