
<div id="editor">



<div id="title"><h1>Add Category</h1>


<?php echo "<p style=\"signp\" align=\"center\">$msg</p>"; ?>
<p>Enter Name of New Category :</p>
<form name="EditorForm" method="POST" action="">
<input class="fulledit" type="text" name="category_name" required>
</div>

  <div id="sb"> <input class="sbt" type="submit" value="Add" name="add_category_button"></div>
</form>

<br />
</div>
</div>