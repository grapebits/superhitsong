<div id="editor">

<div id="loginarea">
<h1>Login - GrapeBits</h1>
<?php
echo("<div style=\"background-color:red;color:blue;\"><p align=\"center\">$error</p></div>");
?>
<form name="login" method="POST" action="">
Username :<br /><input class="loginusername" type="text" name="username" required><br /><br />
Password :<br /><input class="loginpassword" type="password" name="password" required><br /><br />
<input type="submit" name="submit" class="loginsubmit" value="Login">
</form>



<br />
</div>

<br />
</div>
</div>