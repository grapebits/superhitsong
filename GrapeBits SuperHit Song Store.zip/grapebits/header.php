<html>
<head>
<title>GrapeBits</title>
<link rel="shortcut icon" type="image/x-icon" href="assets/image/grape.gif" />

<link href="assets/css/home1.css" rel='stylesheet' type='text/css' />
<script>UPLOADCARE_PUBLIC_KEY = 'your_public_key';</script>
<script src="ckeditor/ckeditor/ckeditor.js"></script>
<link rel="stylesheet" href="assets/cssmenu/apple/styles.css">
</head>

<body>
<div id="content">

<div id="header">
<img src="assets/image/grape_edit.gif" alt="Logo GrapeBits">

 <p class="hp"><br />Grapebits is CMS project.
   <br />You are using GrapeBits v1.0 ,Created by <a href="http://instagram.com/harsh_comp">Harsh Mishra</a>.
 <br /><a href="http://github.com/grapebits">Check the project at github</a>
 </p>
</div>
<!---------------------------------------------------------------------!>
       <div id='cssmenu'>

<ul>



<li class='logout'><a href='login.php'><span>Account</span></a></li>


</ul>


</div>



