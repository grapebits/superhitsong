<?php 
 include "header.php";
 include "signupbody.php";
 include "footer.php"
 
?>