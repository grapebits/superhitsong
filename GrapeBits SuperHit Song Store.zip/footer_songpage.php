<center><?php include "../../adds/page_add4.php"; ?></center>
<h2>About</h2>
<div class="pgn"><a href="<?php echo $developer_url2; ?>" target="_blank">About Developer</a></div>
<div class="pgn"><a href="http://github.com/grapebits" target="_blank">Powered by GrapeBits</a></div>
<center><?php include "../../adds/page_add5.php"; ?></center>
<div class="ftrLink"><a class="siteLink" href="<?php echo $site_url; ?>" style="font-size:14px"><?php echo $site_name; ?> &copy 2018</a></div>
</body></html>