<?php
$site_owner='GrapeBits';
$site_name="SuperHit Song Store";
$site_url='';
$developer_url2='../../about.html';
$developer_url='about.html';
?>