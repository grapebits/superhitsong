<?php
header("Location: ../grapebits/login.php");
?>